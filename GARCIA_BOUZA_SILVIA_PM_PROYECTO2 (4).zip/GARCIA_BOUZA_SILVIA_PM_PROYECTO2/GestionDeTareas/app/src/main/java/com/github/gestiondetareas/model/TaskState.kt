package com.github.gestiondetareas.model


import com.github.gestiondetareas.data.Task

data class TaskState(
    val taskList: List<Task> = emptyList(),
)