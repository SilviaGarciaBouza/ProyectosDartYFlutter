package com.github.gestiondetareas.viewmodel


import androidx.lifecycle.ViewModel
import com.github.gestiondetareas.data.Task
import com.github.gestiondetareas.data.TasksDataSource
import com.github.gestiondetareas.model.TaskState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class TaskViewModel : ViewModel() {
    val listTasks: List<Task> = TasksDataSource.loadTasks()

    private val _listTareasState =
        MutableStateFlow(TaskState(taskList = listTasks))
    val listTareasState: StateFlow<TaskState> = _listTareasState

    fun changeIsCompleted(idTask: Int) {
        val currentListTasks = _listTareasState.value.taskList
        val updateListTAsk = currentListTasks.map {
            e ->
            if(e.id == idTask){
                e.copy(completed = !e.completed)
            }else{e}
        }
        //val updatedPendingTasks =updateListTAsk.count{!it.completed}
        _listTareasState.value =
            _listTareasState.value.copy(taskList = updateListTAsk)
    }



}