import 'dart:io';
import 'dart:math';

void main(List<String> args) {
  int num = Random().nextInt(100) + 1;
  int num2 = -1;
  int count = 0;
  do {
    count++;
    print('Adivina: ');
    num2 = int.tryParse(stdin.readLineSync() ?? '') ?? 0;

    if (num2 < num) {
      print('Tu intento fue Menor');
    } else if (num2 > num) {
      print('Tu intento fue  MAyor');
    }
  } while (num2 != num);
  print('acertaste en $count intentos');
}
